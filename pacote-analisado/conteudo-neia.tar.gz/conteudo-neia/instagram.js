// PUBLICACAO NO INSTAGRAM
// A Meta nao aceita upload de arquivo: ela BUSCA a imagem numa URL publica https.
// Por isso cada publicacao abre um endereco temporario e secreto, que expira sozinho.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const db = require('./db');

const API = 'https://graph.facebook.com/v21.0';
const VALIDADE_MIN = 30;

function cfg(nome, env) {
  const l = db.prepare('SELECT valor FROM config WHERE chave = ?').get(nome);
  return (l && l.valor) || process.env[env] || '';
}

// Sem token e sem conta configurados, a publicacao direta simplesmente nao existe neste app
function ligado() {
  return !!(cfg('meta_token', 'META_TOKEN') && cfg('ig_user_id', 'IG_USER_ID'));
}

function credenciais() {
  const token = cfg('meta_token', 'META_TOKEN');
  const conta = cfg('ig_user_id', 'IG_USER_ID');
  if (!token || !conta) throw new Error('Faltam o token da Meta e o ID da conta do Instagram em Configurações.');
  return { token, conta };
}

// ---------- passe temporario para a Meta buscar as imagens ----------
db.exec(`
CREATE TABLE IF NOT EXISTS passes (
  token TEXT PRIMARY KEY,
  carrossel_id INTEGER,
  expira_em TEXT
);
CREATE TABLE IF NOT EXISTS publicacoes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  carrossel_id INTEGER,
  formato TEXT,
  titulo TEXT,
  publicado_em TEXT,
  media_id TEXT,
  permalink TEXT,
  manual INTEGER DEFAULT 0,
  nota TEXT
);
`);

function abrirPasse(carrosselId) {
  const token = crypto.randomBytes(24).toString('hex');
  const expira = new Date(Date.now() + VALIDADE_MIN * 60000).toISOString();
  db.prepare('INSERT INTO passes (token, carrossel_id, expira_em) VALUES (?,?,?)')
    .run(token, carrosselId, expira);
  // limpa os vencidos de tempos em tempos
  db.prepare('DELETE FROM passes WHERE expira_em < ?').run(new Date().toISOString());
  return token;
}

function validarPasse(token) {
  const p = db.prepare('SELECT * FROM passes WHERE token = ?').get(token);
  if (!p) return null;
  if (p.expira_em < new Date().toISOString()) {
    db.prepare('DELETE FROM passes WHERE token = ?').run(token);
    return null;
  }
  return p;
}

function fecharPasse(token) {
  db.prepare('DELETE FROM passes WHERE token = ?').run(token);
}

// ---------- chamadas a Meta ----------
async function meta(caminho, corpo) {
  const url = `${API}/${caminho}`;
  const r = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams(corpo).toString(),
  });
  const j = await r.json();
  if (j.error) throw new Error(j.error.message || 'A Meta recusou a chamada.');
  return j;
}

async function metaGet(caminho, params) {
  const url = `${API}/${caminho}?${new URLSearchParams(params).toString()}`;
  const r = await fetch(url);
  const j = await r.json();
  if (j.error) throw new Error(j.error.message || 'A Meta recusou a consulta.');
  return j;
}

// O que sobe: os JPEG da pasta de saida.
// Conteudo exportado antes de a publicacao existir so tem PNG: converte na hora, sem pedir nada a ela.
const { execFileSync } = require('child_process');
const FFMPEG = process.env.FFMPEG_PATH || (fs.existsSync('/usr/bin/ffmpeg') ? '/usr/bin/ffmpeg'
  : path.join(process.env.HOME || '', 'bin', 'ffmpeg'));

function imagensDe(carrosselId) {
  const pasta = path.join(__dirname, 'saidas', String(carrosselId));
  if (!fs.existsSync(pasta)) return [];

  const pngs = fs.readdirSync(pasta).filter(f => /^slide-\d+\.png$/.test(f)).sort();
  for (const png of pngs) {
    const jpg = png.replace('.png', '.jpg');
    if (fs.existsSync(path.join(pasta, jpg))) continue;
    try {
      execFileSync(FFMPEG, ['-y', '-i', path.join(pasta, png), '-q:v', '3', path.join(pasta, jpg)],
        { stdio: 'pipe' });
    } catch (e) { /* segue com o que der */ }
  }

  return fs.readdirSync(pasta).filter(f => /^slide-\d+\.jpg$/.test(f)).sort();
}

async function quotaRestante() {
  const { token, conta } = credenciais();
  const d = await metaGet(`${conta}/content_publishing_limit`, {
    fields: 'quota_usage,config', access_token: token,
  });
  const x = (d.data || [{}])[0];
  return { usadas: x.quota_usage || 0, total: (x.config || {}).quota_total || 100 };
}

// Antes de publicar, ela ve exatamente o que vai subir
function previa(carrosselId) {
  const c = db.prepare('SELECT id, tema, formato, legenda, comentario, status FROM carrosseis WHERE id = ?')
    .get(carrosselId);
  if (!c) throw new Error('Conteúdo não encontrado.');
  const imagens = imagensDe(carrosselId);
  const problemas = [];
  if (!imagens.length) problemas.push('Não achei as imagens deste conteúdo. Clique em Exportar imagens antes de publicar.');
  if (imagens.length > 10) problemas.push(`O Instagram aceita no máximo 10 imagens por carrossel, e este tem ${imagens.length}.`);
  if (!(c.legenda || '').trim()) problemas.push('A legenda está vazia.');
  if (c.formato === 'reels' || c.formato === 'live') {
    problemas.push('Reels e Live são vídeo, e o app não gera vídeo. Aqui só dá para publicar a capa como imagem.');
  }
  return { ...c, imagens, problemas };
}

async function publicar({ carrosselId, base }) {
  const { token, conta } = credenciais();
  const c = db.prepare('SELECT id, tema, formato, legenda FROM carrosseis WHERE id = ?').get(carrosselId);
  if (!c) throw new Error('Conteúdo não encontrado.');

  const imagens = imagensDe(carrosselId);
  if (!imagens.length) throw new Error('Não achei as imagens. Exporte as imagens primeiro.');
  if (imagens.length > 10) throw new Error('O Instagram aceita no máximo 10 imagens.');

  const legenda = (c.legenda || '').trim();
  const passe = abrirPasse(carrosselId);
  const url = (arquivo) => `${base}/p/${passe}/${arquivo}`;

  try {
    let criacao;

    if (imagens.length === 1) {
      const r = await meta(`${conta}/media`, {
        image_url: url(imagens[0]), caption: legenda, access_token: token,
      });
      criacao = r.id;
    } else {
      // Cada imagem vira um item, e depois todos viram um carrossel
      const filhos = [];
      for (const img of imagens) {
        const r = await meta(`${conta}/media`, {
          image_url: url(img), is_carousel_item: 'true', access_token: token,
        });
        filhos.push(r.id);
      }
      const r = await meta(`${conta}/media`, {
        media_type: 'CAROUSEL', children: filhos.join(','), caption: legenda, access_token: token,
      });
      criacao = r.id;
    }

    const pub = await meta(`${conta}/media_publish`, {
      creation_id: criacao, access_token: token,
    });

    let permalink = '';
    try {
      const d = await metaGet(pub.id, { fields: 'permalink', access_token: token });
      permalink = d.permalink || '';
    } catch (e) {}

    const agora = new Date().toISOString();
    db.prepare(`INSERT INTO publicacoes (carrossel_id, formato, titulo, publicado_em, media_id, permalink, manual)
      VALUES (?,?,?,?,?,?,0)`)
      .run(c.id, c.formato || 'carrossel', c.tema || '', agora, pub.id, permalink);
    db.prepare('UPDATE carrosseis SET status = ?, atualizado_em = ? WHERE id = ?')
      .run('publicado', agora, c.id);

    return { media_id: pub.id, permalink, publicado_em: agora, imagens: imagens.length };
  } finally {
    fecharPasse(passe);
  }
}

module.exports = { previa, publicar, quotaRestante, validarPasse, credenciais, imagensDe, ligado };
