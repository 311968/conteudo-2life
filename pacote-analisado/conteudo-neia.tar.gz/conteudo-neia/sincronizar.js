#!/usr/bin/env node
// Sincroniza o Mac com a VPS. Sempre manual, nunca automatico.
//   node sincronizar.js exportar   -> gera pacote.json aqui
//   node sincronizar.js importar   -> aplica pacote.json (roda na VPS)
//
// O que viaja: Identidade, o cadastro das fotos e SO as notas das pastas liberadas
// do segundo cerebro. Sessao de mentoria e projeto interno ficam no Mac.
const fs = require('fs');
const path = require('path');
const db = require('./db');
const cerebro = require('./cerebro');

const ARQUIVO = path.join(__dirname, 'pacote.json');

function exportar() {
  const identidade = db.prepare('SELECT tipo, conteudo, atualizado_em FROM identidade').all();
  const fotos = db.prepare('SELECT arquivo, rotulo, criado_em FROM fotos').all();
  const config = db.prepare("SELECT chave, valor FROM config WHERE chave IN ('handle','marca','linha_visual','cerebro_pastas')").all();

  const { publicas } = cerebro.separarPorDestino();
  const marca = publicas.map(() => 'pasta = ? OR pasta LIKE ?').join(' OR ');
  const parametros = publicas.flatMap(p => [p, p + '/%']);
  const notas = db.prepare(
    `SELECT caminho, titulo, pasta, conteudo, modificado_em FROM cerebro WHERE ${marca}`
  ).all(...parametros);

  const pacote = { gerado_em: new Date().toISOString(), identidade, fotos, config, notas, pastas_liberadas: publicas };
  fs.writeFileSync(ARQUIVO, JSON.stringify(pacote));

  const mb = (fs.statSync(ARQUIVO).size / 1048576).toFixed(1);
  console.log(`pacote.json: ${mb} MB`);
  console.log(`  identidade: ${identidade.length} blocos`);
  console.log(`  fotos: ${fotos.length}`);
  console.log(`  segundo cérebro: ${notas.length} notas (pastas: ${publicas.join(', ')})`);
  const total = db.prepare('SELECT COUNT(*) c FROM cerebro').get().c;
  console.log(`  ficaram no Mac: ${total - notas.length} notas`);
}

function importar() {
  if (!fs.existsSync(ARQUIVO)) throw new Error('Não achei o pacote.json.');
  const p = JSON.parse(fs.readFileSync(ARQUIVO, 'utf8'));
  const agora = new Date().toISOString();

  const ident = db.prepare(`INSERT INTO identidade (tipo, conteudo, atualizado_em) VALUES (?,?,?)
    ON CONFLICT(tipo) DO UPDATE SET conteudo=excluded.conteudo, atualizado_em=excluded.atualizado_em`);
  for (const i of p.identidade) ident.run(i.tipo, i.conteudo, i.atualizado_em || agora);

  const cfg = db.prepare(`INSERT INTO config (chave, valor) VALUES (?,?)
    ON CONFLICT(chave) DO UPDATE SET valor=excluded.valor`);
  for (const c of p.config || []) cfg.run(c.chave, c.valor);

  const temFoto = db.prepare('SELECT 1 FROM fotos WHERE arquivo = ?');
  const novaFoto = db.prepare('INSERT INTO fotos (arquivo, rotulo, criado_em) VALUES (?,?,?)');
  const upFoto = db.prepare('UPDATE fotos SET rotulo = ? WHERE arquivo = ?');
  for (const f of p.fotos) {
    if (temFoto.get(f.arquivo)) upFoto.run(f.rotulo, f.arquivo);
    else novaFoto.run(f.arquivo, f.rotulo, f.criado_em || agora);
  }

  // Segundo cerebro: troca o conteudo inteiro pelo que veio do Mac
  db.prepare('DELETE FROM cerebro').run();
  const nota = db.prepare(`INSERT INTO cerebro (caminho, titulo, pasta, conteudo, modificado_em, indexado_em)
    VALUES (?,?,?,?,?,?)`);
  const lote = db.transaction(() => {
    for (const n of p.notas) nota.run(n.caminho, n.titulo, n.pasta, n.conteudo, n.modificado_em, agora);
  });
  lote();
  cfg.run('cerebro_indexado_em', p.gerado_em);

  console.log(`importado: ${p.identidade.length} blocos de identidade, ${p.fotos.length} fotos, ${p.notas.length} notas`);
}

const acao = process.argv[2];
if (acao === 'exportar') exportar();
else if (acao === 'importar') importar();
else { console.log('use: node sincronizar.js exportar | importar'); process.exit(1); }
