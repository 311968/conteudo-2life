// Geracao de imagem por lamina, a partir da direcao de imagem que a IA escreveu.
const fs = require('fs');
const path = require('path');
const db = require('./db');

function chave() {
  const linha = db.prepare('SELECT valor FROM config WHERE chave = ?').get('gemini_api_key');
  return (linha && linha.valor) || process.env.GEMINI_API_KEY || '';
}

// Proporcao pedida por tipo de lamina, para a imagem nascer no formato certo
const PROPORCAO = {
  layout1: { capa: '4:5', fechamento: '4:5', texto: '4:5', caixas: '4:5', cheia: '4:5' },
  layout2: { capa: '4:5', imagem_topo: '16:9', imagem_base: '16:9', meia: '9:16', lista: '4:5', fechamento: '4:5' },
};

// A linha visual da marca entra em toda imagem, para o carrossel inteiro ter a mesma cara
const ESTILO = [
  'Fotografia editorial, luz natural, profundidade de campo suave, aspecto de revista de negocios sofisticada.',
  'Paleta creme, areia e verde petroleo escuro, com um toque de dourado envelhecido. Nada saturado, nada neon.',
  'Composicao limpa, sobria, adulta. Sem colagem, sem ilustracao, sem 3D, sem aparencia de banco de imagens generico.',
  'Se houver pessoa na cena, ela aparece de costas, de lado ou cortada, nunca com o rosto em foco.',
].join(' ');

// Repetido no fim do prompt de proposito: e a instrucao que o modelo mais desobedece
const SEM_TEXTO = [
  'REGRA FINAL, A MAIS IMPORTANTE: a imagem nao pode conter NENHUM texto.',
  'Nada de palavra, letra, numero, legenda, titulo, placa, cartaz, logotipo, marca dagua,',
  'nem tela de computador ou celular com texto legivel. Se algum aparelho aparecer, a tela fica desligada,',
  'desfocada ou mostrando apenas formas e cores. Imagem puramente visual, sem escrita alguma.',
].join(' ');

async function gerar({ descricao, tipo, layout, contexto }) {
  const key = chave();
  if (!key) throw new Error('Falta a chave do Gemini em Configuracoes.');
  if (!descricao || !descricao.trim()) throw new Error('Esta lamina esta sem direcao de imagem.');

  const proporcao = (PROPORCAO[layout] || PROPORCAO.layout2)[tipo] || '4:5';
  // O texto da lamina NAO entra no prompt: o modelo tenta desenhar as palavras que le.
  const prompt = [
    `Crie a imagem desta lamina de carrossel: ${descricao.trim()}`,
    ESTILO,
    SEM_TEXTO,
  ].join('\n\n');

  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-image:generateContent?key=${key}`;
  const r = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: { imageConfig: { aspectRatio: proporcao } },
    }),
  });
  if (!r.ok) throw new Error('Gemini respondeu ' + r.status + ': ' + (await r.text()).slice(0, 240));

  const j = await r.json();
  const partes = j?.candidates?.[0]?.content?.parts || [];
  const img = partes.find(p => p.inlineData || p.inline_data);
  if (!img) {
    const recusa = partes.map(p => p.text).filter(Boolean).join(' ').slice(0, 200);
    throw new Error('O Gemini nao devolveu imagem. ' + (recusa || 'Tente outra descricao.'));
  }
  const dados = (img.inlineData || img.inline_data).data;
  const nome = `img-${Date.now()}-${Math.random().toString(36).slice(2, 7)}.png`;
  fs.writeFileSync(path.join(__dirname, 'geradas', nome), Buffer.from(dados, 'base64'));
  return 'geradas/' + nome;
}

// Lamina que leva imagem gerada (as do meio). Capa e fechamento ficam com a foto dela.
const GERA = {
  layout1: [],
  layout2: ['imagem_topo', 'imagem_base', 'meia'],
};
function geraImagem(layout, tipo) {
  return (GERA[layout] || []).includes(tipo);
}

module.exports = { gerar, geraImagem, PROPORCAO };
