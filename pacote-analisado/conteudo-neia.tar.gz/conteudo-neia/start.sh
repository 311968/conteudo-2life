#!/bin/bash
cd "$(dirname "$0")"
pkill -f "node server.js" 2>/dev/null
sleep 1
node server.js
