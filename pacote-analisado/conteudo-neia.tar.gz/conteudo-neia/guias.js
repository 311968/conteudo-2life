// GUIAS — o que aparece na Identidade de um app recem instalado.
// Em vez de campos vazios, a pessoa encontra as perguntas que precisa responder.
const GUIAS = {
  posicionamento: `# Posicionamento

Escreva aqui, com as suas palavras:

- O que você faz, para quem, e o que muda na vida dela
- A frase que você usaria se alguém perguntasse "o que você faz?" numa festa
- O que você defende que a maioria do seu mercado não defende
- O que você nunca faria, mesmo que desse dinheiro`,

  persona: `# Persona

Descreva a sua cliente ideal como se estivesse falando de uma pessoa real:

- Em que momento do negócio ela está
- O que ela já tentou e não funcionou
- Do que ela tem medo, e o que ela não admite em voz alta
- Como ela fala, o que ela lê, onde ela procura solução
- O que faz ela decidir comprar`,

  voz: `# Tom de voz

- Como você fala: direta, professora, provocadora, acolhedora?
- Como você chama a sua cliente ("você", o nome dela, outra coisa)
- Cinco frases suas que se repetem, as que as clientes já reconhecem
- Palavras que você NUNCA usa
- Um exemplo de parágrafo escrito exatamente como você falaria`,

  metodologia: `# Método

- O nome do seu método, se tiver
- Os passos ou pilares, na ordem
- O que você faz diferente de quem faz parecido
- Uma explicação do método em três frases, para quem nunca ouviu falar`,

  produtos: `# Produtos

Para cada oferta:

- Nome e preço
- Para quem é, e para quem não é
- O que está incluído
- Qual transformação ela entrega
- Como a pessoa entra`,

  regras: `# Regras da sua marca

O que a IA precisa respeitar em todo conteúdo que escrever para você.

Como você chama a sua cliente
- Você fala "você"? Chama pelo nome? Evita alguma palavra para se dirigir a ela?

Palavras que você NUNCA usa
- Liste as que te dão arrepio. Exemplo: guru, hack, segredo, fórmula mágica, escala rápida.

Promessas que você não faz
- O que o seu mercado promete e você se recusa a prometer?

A ordem do seu discurso
- Por onde você entra numa conversa, e o que só aparece depois que a pessoa confia?

Qualquer outra regra
- Escreva como se estivesse orientando alguém que vai escrever no seu lugar.`,

  provas: `# Provas

Só casos que existem de verdade. A IA tem ordem de nunca inventar cliente.

Para cada caso:
- Quem era (sem nome, se preferir: "uma contadora que atendo")
- Como ela chegou
- O que foi feito
- O que mudou, com número quando tiver`,
};

module.exports = { GUIAS };
