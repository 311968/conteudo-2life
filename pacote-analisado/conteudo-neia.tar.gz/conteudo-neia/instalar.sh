#!/bin/bash
# INSTALADOR — Conteúdo Negócio Enxuto com IA
# Rode este arquivo na SUA VPS. Ele pergunta o que precisa e deixa o app no ar.
set -e

verde()  { printf "\033[0;32m%s\033[0m\n" "$1"; }
ouro()   { printf "\033[0;33m%s\033[0m\n" "$1"; }
erro()   { printf "\033[0;31m%s\033[0m\n" "$1"; }

echo
ouro "═══════════════════════════════════════════"
ouro "  CONTEÚDO NEGÓCIO ENXUTO COM IA"
ouro "  Instalação no seu servidor"
ouro "═══════════════════════════════════════════"
echo

[ "$EUID" -ne 0 ] && { erro "Rode como root:  sudo bash instalar.sh"; exit 1; }

# ── 1. As perguntas ────────────────────────────────────────
# Quando o instalador chega por "curl | bash", a entrada do teclado esta ocupada
# pelo proprio script. Entao lemos direto do terminal.
if [ -t 0 ]; then
  ENTRADA=/dev/stdin
elif [ -e /dev/tty ] && (exec </dev/tty) 2>/dev/null; then
  ENTRADA=/dev/tty
else
  ENTRADA=/dev/stdin
fi

[ -z "$DOMINIO" ] && read -rp "Seu domínio (ex: conteudo.seusite.com.br): " DOMINIO < "$ENTRADA"
[ -z "$DOMINIO" ] && { erro "Preciso do domínio."; exit 1; }

[ -z "$USUARIO" ] && read -rp "Login que você vai usar para entrar: " USUARIO < "$ENTRADA"
[ -z "$USUARIO" ] && USUARIO="admin"

if [ -z "$SENHA" ]; then
  read -rsp "Senha (mínimo 8 caracteres): " SENHA < "$ENTRADA"; echo
fi
[ ${#SENHA} -lt 8 ] && { erro "A senha precisa de pelo menos 8 caracteres."; exit 1; }

[ -z "$EMAIL" ] && read -rp "Seu email (para o certificado de segurança): " EMAIL < "$ENTRADA"
[ -z "$EMAIL" ] && { erro "Preciso do email."; exit 1; }

# O nome vem do domínio, para nunca pisar num app que já esteja rodando aqui
APELIDO=$(echo "$DOMINIO" | cut -d. -f1 | tr -cd 'a-z0-9-')
[ -z "$APELIDO" ] && APELIDO="conteudo"

if pm2 describe "$APELIDO" >/dev/null 2>&1; then
  erro "Já existe um app chamado \"$APELIDO\" rodando neste servidor."
  erro "Escolha outro domínio, ou pare o app antigo antes:  pm2 delete $APELIDO"
  exit 1
fi
if [ -e "/etc/nginx/sites-enabled/$DOMINIO" ]; then
  erro "O endereço $DOMINIO já está configurado no nginx deste servidor."
  erro "Escolha outro domínio, ou remova a configuração antiga antes."
  exit 1
fi
if [ -e "/var/www/$DOMINIO" ]; then
  erro "A pasta /var/www/$DOMINIO já existe. Escolha outro domínio."
  exit 1
fi

echo
ouro "→ Conferindo se o domínio aponta para este servidor..."
MEU_IP=$(curl -s -4 ifconfig.me || echo "")
DNS_IP=$(getent hosts "$DOMINIO" | awk '{print $1}' | head -1 || echo "")
if [ -n "$MEU_IP" ] && [ "$MEU_IP" != "$DNS_IP" ]; then
  erro "O domínio $DOMINIO não está apontando para este servidor ($MEU_IP)."
  erro "Crie um registro A apontando para $MEU_IP e rode de novo."
  exit 1
fi
verde "  domínio ok"

# ── 2. O que o app precisa ─────────────────────────────────
echo
ouro "→ Instalando o que o app precisa (leva alguns minutos)..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq

command -v node >/dev/null || {
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash - >/dev/null 2>&1
  apt-get install -y -qq nodejs
}
verde "  node $(node -v)"

for pacote in nginx certbot python3-certbot-nginx ffmpeg zip curl; do
  dpkg -s "$pacote" >/dev/null 2>&1 || apt-get install -y -qq "$pacote"
done
verde "  nginx, certbot, ffmpeg e zip"

command -v google-chrome-stable >/dev/null || {
  curl -fsSL https://dl.google.com/linux/linux_signing_key.pub | gpg --dearmor -o /usr/share/keyrings/google-chrome.gpg 2>/dev/null
  echo 'deb [arch=amd64 signed-by=/usr/share/keyrings/google-chrome.gpg] http://dl.google.com/linux/chrome/deb/ stable main' > /etc/apt/sources.list.d/google-chrome.list
  apt-get update -qq
  apt-get install -y -qq google-chrome-stable
}
verde "  chrome (é ele que desenha as suas artes)"

command -v pm2 >/dev/null || npm install -g pm2 --silent
verde "  pm2 (mantém o app ligado)"

# ── 3. O app ───────────────────────────────────────────────
DESTINO=/var/www/$DOMINIO
echo
ouro "→ Colocando o app em $DESTINO..."
mkdir -p "$DESTINO"
cp -r ./* "$DESTINO"/ 2>/dev/null || true
cd "$DESTINO"
mkdir -p fotos saidas geradas uploads
rm -f instalar.sh deploy.sh provisionar-aluna.sh pacote.json

cat > .env <<EOF
PORT=$(PORTA=3900; while ss -ltn 2>/dev/null | grep -q ":$PORTA "; do PORTA=$((PORTA+1)); done; echo $PORTA)
APP_USER=$USUARIO
APP_PASS=$SENHA
SESSION_SECRET=$(openssl rand -hex 24)
CHROME_PATH=/usr/bin/google-chrome-stable
FFMPEG_PATH=/usr/bin/ffmpeg
EOF
chmod 600 .env
PORTA=$(grep '^PORT=' .env | cut -d= -f2)

npm install --omit=dev --silent
verde "  app instalado"

# ── 4. No ar ───────────────────────────────────────────────
echo
ouro "→ Ligando..."
pm2 start server.js --name "$APELIDO" --time >/dev/null
pm2 save >/dev/null 2>&1
pm2 startup systemd -u root --hp /root >/dev/null 2>&1 || true

cat > /etc/nginx/sites-available/$DOMINIO <<EOF
server {
    listen 80;
    server_name $DOMINIO;
    client_max_body_size 100M;
    location / {
        proxy_pass http://127.0.0.1:$PORTA;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_read_timeout 600s;
        proxy_send_timeout 600s;
    }
}
EOF
ln -sf /etc/nginx/sites-available/$DOMINIO /etc/nginx/sites-enabled/
nginx -t >/dev/null 2>&1 && systemctl reload nginx
verde "  endereço configurado"

# Espera o nginx realmente atender no endereço antes de pedir o certificado
ouro "→ Esperando o endereço responder..."
for _ in $(seq 1 20); do
  curl -sf -o /dev/null --max-time 5 "http://$DOMINIO/" && break
  sleep 2
done

CERTOK=0
for tentativa in 1 2; do
  if certbot --nginx -d "$DOMINIO" --non-interactive --agree-tos -m "$EMAIL" --redirect >/tmp/certbot-saida.txt 2>&1; then
    CERTOK=1; break
  fi
  sleep 8
done

if [ "$CERTOK" = "1" ]; then
  verde "  cadeado de segurança emitido"
else
  erro "  o certificado não saiu. O app já está no ar em http://$DOMINIO"
  erro "  para tentar de novo:  certbot --nginx -d $DOMINIO"
  erro "  o motivo está em /tmp/certbot-saida.txt"
fi

sleep 2
echo
ouro "═══════════════════════════════════════════"
verde " Pronto. O seu app está em:"
echo
echo "   https://$DOMINIO"
echo "   login: $USUARIO"
echo
echo "   o app se chama \"$APELIDO\" aqui dentro do servidor"
echo "   para ver o que ele diz:  pm2 logs $APELIDO"
echo
ouro " Os próximos passos estão no LEIA-ME.md"
ouro "═══════════════════════════════════════════"
echo
