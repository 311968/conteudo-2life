# Conteúdo Negócio Enxuto com IA

O seu estúdio de conteúdo: carrossel, post, reels e live, escritos no seu tom,
com as suas artes, no seu servidor.

## Instalar

Você precisa de:
- Uma VPS com Ubuntu e o acesso root
- Um domínio ou subdomínio livre, apontando para o IP da VPS
- Cartão de crédito, para criar as chaves de IA

No seu computador:

    scp conteudo-neia.tar.gz root@SEU_IP:/root/

Na VPS:

    ssh root@SEU_IP
    cd /root
    tar -xzf conteudo-neia.tar.gz
    cd conteudo-neia
    bash instalar.sh

Ele pergunta o domínio, o login, a senha e o seu email. Depois instala tudo
sozinho e mostra o endereço do seu app.

## Depois de instalar

Entre no app e vá direto na aba **Tutorial**. Ela mostra o que falta fazer e
marca sozinha o que já está pronto:

1. Cadastrar as suas chaves de IA
2. Escrever a sua identidade
3. Subir as suas fotos
4. Colocar as suas cores
5. Fazer o primeiro conteúdo

## O que roda por baixo

- Node com Express e um banco SQLite, tudo dentro da pasta do app
- Chrome, que é quem desenha as suas artes
- ffmpeg, que converte os seus áudios antes de transcrever
- nginx e certbot, que cuidam do endereço e do cadeado de segurança
- pm2, que mantém o app ligado, inclusive depois de reiniciar a VPS

## Onde ficam as suas coisas

    fotos/     as suas fotos
    saidas/    as imagens geradas, uma pasta por conteúdo
    geradas/   as imagens criadas por IA
    conteudo.db   o banco: identidade, conteúdos, calendário
    .env       as senhas e a porta. Nunca compartilhe

## Fazer backup

Copie estes quatro para um lugar seguro, de vez em quando:

    conteudo.db  fotos/  .env  geradas/

## Se algo parar

    pm2 logs conteudo     ver o que o app está dizendo
    pm2 restart conteudo  reiniciar
    pm2 resurrect         trazer de volta depois de reiniciar a VPS
